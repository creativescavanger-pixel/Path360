import { useNavigate } from 'react-router-dom'

function Label({ children, tone = 'lilac' }) {
  const colors = {
    lilac: 'var(--lilac-700, #694FB2)',
    green: 'var(--green-700, #1A704D)',
    muted: 'var(--text-faint, #899089)',
  }

  return (
    <div
      style={{
        color: colors[tone],
        fontSize: 10,
        fontWeight: 850,
        letterSpacing: '.12em',
        textTransform: 'uppercase',
        marginBottom: 7,
      }}
    >
      {children}
    </div>
  )
}

function ActionButton({ children, onClick, tone = 'primary' }) {
  const styles = {
    primary: {
      background: 'var(--green-700, #1A704D)',
      color: '#FFFFFF',
      border: '1px solid var(--green-700, #1A704D)',
    },
    secondary: {
      background: '#FFFFFF',
      color: 'var(--text-soft, #5D635D)',
      border: '1px solid var(--border, #DDE2DC)',
    },
    lilac: {
      background: 'var(--lilac-050, #F8F6FF)',
      color: 'var(--lilac-800, #5B449D)',
      border: '1px solid var(--lilac-200, #DED5F6)',
    },
  }

  return (
    <button
      type="button"
      onClick={onClick}
      style={{
        ...styles[tone],
        borderRadius: 10,
        padding: '10px 13px',
        fontSize: 12,
        fontWeight: 850,
        cursor: 'pointer',
      }}
    >
      {children}
    </button>
  )
}

export default function WorkshopStagePanel({
  stage,
  isRecommended,
  onBack,
  onStart,
  onOpenMission,
}) {
  const navigate = useNavigate()

  function openResources() {
    navigate(`/app/resources?stage=${stage.key}`)
  }

  function openFrameworks() {
    navigate(`/app/resources?view=frameworks&stage=${stage.key}`)
  }

  function openModule(module, index) {
    if (stage.key === 'discover' && index === 0) {
      onOpenMission('opportunity-foundations')
      return
    }

    if (stage.key === 'discover' && index === 1) {
      onOpenMission('notice-friction')
      return
    }

    onStart()
  }

  return (
    <div
      style={{
        padding: 24,
        maxWidth: 1160,
        margin: '0 auto',
        fontFamily: 'var(--font-sans, DM Sans, sans-serif)',
        color: 'var(--text, #151614)',
      }}
    >
      <button
        type="button"
        onClick={onBack}
        style={{
          border: 0,
          padding: 0,
          marginBottom: 14,
          background: 'transparent',
          color: 'var(--lilac-700, #694FB2)',
          fontSize: 12.5,
          fontWeight: 800,
          cursor: 'pointer',
        }}
      >
        ← Back to Founder Workshop
      </button>

      <section
        style={{
          padding: '28px 28px',
          borderRadius: 20,
          background:
            'linear-gradient(135deg, #FFFFFF 0%, var(--lilac-050, #F8F6FF) 100%)',
          border: '1px solid var(--lilac-200, #DED5F6)',
          marginBottom: 16,
        }}
      >
        <Label>
          Stage {stage.number} · {stage.label} Workshop
        </Label>

        <div
          style={{
            display: 'flex',
            alignItems: 'flex-start',
            justifyContent: 'space-between',
            gap: 16,
            flexWrap: 'wrap',
          }}
        >
          <div style={{ maxWidth: 760 }}>
            <h1
              style={{
                margin: '0 0 9px',
                fontSize: 30,
                letterSpacing: '-.045em',
                lineHeight: 1.12,
              }}
            >
              {stage.title}
            </h1>

            <p
              style={{
                margin: '0 0 10px',
                color: 'var(--text-soft, #5D635D)',
                fontSize: 13.5,
                lineHeight: 1.7,
              }}
            >
              {stage.description}
            </p>

            <div
              style={{
                color: 'var(--green-800, #15563E)',
                fontSize: 11.5,
                fontWeight: 750,
              }}
            >
              Founder question: {stage.question}
            </div>

            {stage.duration ? (
              <div
                style={{
                  marginTop: 5,
                  color: 'var(--text-faint, #899089)',
                  fontSize: 11.5,
                }}
              >
                Suggested pace: {stage.duration}
              </div>
            ) : null}
          </div>

          {isRecommended ? (
            <div
              style={{
                padding: '8px 10px',
                borderRadius: 999,
                background: 'var(--green-100, #E9F4EC)',
                color: 'var(--green-800, #15563E)',
                border: '1px solid rgba(26,112,77,.18)',
                fontSize: 11,
                fontWeight: 850,
              }}
            >
              Recommended current focus
            </div>
          ) : null}
        </div>

        <div
          style={{
            display: 'flex',
            gap: 10,
            flexWrap: 'wrap',
            marginTop: 18,
          }}
        >
          <ActionButton onClick={onStart}>Start this workshop →</ActionButton>
          <ActionButton tone="secondary" onClick={openResources}>
            View stage resources →
          </ActionButton>
          <ActionButton tone="lilac" onClick={openFrameworks}>
            Browse related frameworks →
          </ActionButton>
        </div>
      </section>

      <div
        style={{
          display: 'grid',
          gridTemplateColumns: 'minmax(0,1.45fr) minmax(270px,.75fr)',
          gap: 16,
          alignItems: 'start',
        }}
      >
        <main style={{ display: 'grid', gap: 16 }}>
          <section className="p360-card" style={{ padding: 20, borderRadius: 18 }}>
            <Label>Workshop modules</Label>
            <h2
              style={{
                margin: '0 0 8px',
                fontSize: 20,
                letterSpacing: '-.025em',
              }}
            >
              Work through the questions that matter
            </h2>

            <p
              style={{
                margin: '0 0 16px',
                color: 'var(--text-soft, #5D635D)',
                fontSize: 12.5,
                lineHeight: 1.6,
              }}
            >
              This is a working programme—not a short course. Each module
              combines explanation, frameworks, fieldwork, evidence, reflection,
              and practical founder-owned outputs.
            </p>

            <div style={{ display: 'grid', gap: 10 }}>
              {stage.modules.map((module, index) => (
                <article
                  key={`${stage.key}-${module.number}`}
                  style={{
                    display: 'grid',
                    gridTemplateColumns: '46px minmax(0,1fr) auto',
                    gap: 12,
                    alignItems: 'center',
                    padding: '14px 13px',
                    border: '1px solid var(--border, #DDE2DC)',
                    borderRadius: 14,
                    background: 'var(--surface, #FFFFFF)',
                  }}
                >
                  <div
                    style={{
                      width: 36,
                      height: 36,
                      display: 'grid',
                      placeItems: 'center',
                      borderRadius: 999,
                      background: 'var(--green-700, #1A704D)',
                      color: '#FFFFFF',
                      fontSize: 10,
                      fontWeight: 850,
                    }}
                  >
                    {module.number}
                  </div>

                  <div>
                    <div
                      style={{
                        color: 'var(--text, #151614)',
                        fontSize: 13,
                        fontWeight: 850,
                      }}
                    >
                      {module.title}
                    </div>

                    <div
                      style={{
                        marginTop: 5,
                        color: 'var(--lilac-800, #5B449D)',
                        fontSize: 10.7,
                        fontWeight: 800,
                      }}
                    >
                      Framework: {module.framework}
                    </div>

                    <div
                      style={{
                        marginTop: 3,
                        color: 'var(--green-800, #15563E)',
                        fontSize: 10.7,
                        fontWeight: 800,
                      }}
                    >
                      Create: {module.output}
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => openModule(module, index)}
                    style={{
                      border: 0,
                      padding: '5px 2px',
                      background: 'transparent',
                      color: 'var(--green-700, #1A704D)',
                      fontSize: 11,
                      fontWeight: 850,
                      cursor: 'pointer',
                      whiteSpace: 'nowrap',
                    }}
                  >
                    Open →
                  </button>
                </article>
              ))}
            </div>
          </section>

          <section className="p360-card" style={{ padding: 20, borderRadius: 18 }}>
            <Label>Fieldwork</Label>
            <h2 style={{ margin: '0 0 10px', fontSize: 18 }}>
              Take the work into the real world
            </h2>

            <div style={{ display: 'grid', gap: 8 }}>
              {stage.fieldwork.map((item) => (
                <div
                  key={item}
                  style={{
                    display: 'flex',
                    gap: 9,
                    padding: '10px 11px',
                    borderRadius: 11,
                    background: 'var(--surface-soft, #F8F9F6)',
                    border: '1px solid var(--border, #DDE2DC)',
                    color: 'var(--text-soft, #5D635D)',
                    fontSize: 12,
                    lineHeight: 1.5,
                  }}
                >
                  <span style={{ color: 'var(--green-700, #1A704D)', fontWeight: 900 }}>
                    →
                  </span>
                  {item}
                </div>
              ))}
            </div>
          </section>
        </main>

        <aside style={{ display: 'grid', gap: 16 }}>
          <section
            style={{
              padding: 18,
              borderRadius: 18,
              background: 'var(--green-050, #F4FAF6)',
              border: '1px solid rgba(26,112,77,.18)',
            }}
          >
            <Label tone="green">What you will leave with</Label>

            <div style={{ display: 'grid', gap: 8 }}>
              {stage.outputs.map((item) => (
                <div
                  key={item}
                  style={{
                    color: 'var(--text-soft, #5D635D)',
                    fontSize: 12,
                    lineHeight: 1.45,
                  }}
                >
                  <span
                    style={{
                      color: 'var(--green-700, #1A704D)',
                      fontWeight: 900,
                      marginRight: 7,
                    }}
                  >
                    ✓
                  </span>
                  {item}
                </div>
              ))}
            </div>
          </section>

          <section
            style={{
              padding: 18,
              borderRadius: 18,
              background: 'var(--lilac-050, #F8F6FF)',
              border: '1px solid var(--lilac-200, #DED5F6)',
            }}
          >
            <Label>Decision routes</Label>

            <p
              style={{
                margin: '0 0 10px',
                color: 'var(--text-soft, #5D635D)',
                fontSize: 12,
                lineHeight: 1.55,
              }}
            >
              PATH360 does not force one outcome. The evidence you gather
              determines the next useful route.
            </p>

            <div style={{ display: 'grid', gap: 7 }}>
              {stage.decisions.map((item) => (
                <div
                  key={item}
                  style={{
                    padding: '9px 10px',
                    borderRadius: 10,
                    background: '#FFFFFF',
                    border: '1px solid var(--lilac-200, #DED5F6)',
                    color: 'var(--lilac-800, #5B449D)',
                    fontSize: 11.5,
                    fontWeight: 750,
                  }}
                >
                  {item}
                </div>
              ))}
            </div>
          </section>

          <section className="p360-learning-surface" style={{ padding: 18 }}>
            <Label>Capital & opportunity focus</Label>
            <p
              style={{
                margin: 0,
                color: 'var(--text-soft, #5D635D)',
                fontSize: 12,
                lineHeight: 1.6,
              }}
            >
              {stage.capitalFocus ||
                'Identify the resources, support, and evidence needed for the next credible milestone before choosing a capital route.'}
            </p>
          </section>
        </aside>
      </div>
    </div>
  )
}